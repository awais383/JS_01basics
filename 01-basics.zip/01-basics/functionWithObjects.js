user= {
    username: "awais",
    email : "awais@gmail.com",
    age: "20",
}

function handleobject(anyobject){
    console.log(`name is ${anyobject.username} and email is ${anyobject.email}`)
}

 handleobject(user)

 // can also display by this method
handleobject({
    username: "awais",
    email: "awais@gmail.com",
})



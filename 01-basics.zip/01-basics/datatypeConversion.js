//let score= "33"
let score= undefined

// console.log(typeof score)
// console.log(typeof(score))

 let valueInNumber= Number(score)
 console.log(typeof valueInNumber)

// will display nan(not a number)
 console.log(valueInNumber)
 


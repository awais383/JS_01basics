// array in JS is resisable
// array items can also of different types

const myArr= [2,3,4,5,6,7]

// find index
console.log(myArr[3])


// ************array methods************


// add a number at last of array
myArr.push(4)
console.log(myArr)

// remove a number at last of array
myArr.pop()
console.log(myArr)

// add a number at start of array
myArr.unshift(10)
console.log(myArr)

// remove a number at start of array
myArr.shift()
console.log(myArr)

// check whether this number includes or not
console.log(myArr.includes(5))

// checking indexes
console.log(myArr.indexOf(3))
// will give -1 index to unknown value
console.log(myArr.indexOf(200))

// convert array type into string 
const newArr= myArr.join()
console.log(newArr)
console.log(myArr)


// slice
myNewArray= myArr.slice(1,3)
console.log(myNewArray)

// splice
myNewArray= myArr.splice(1,3)
console.log(myNewArray)

// splice
myNewArray2= myArr.splice(1,3)
console.log(myNewArray2)






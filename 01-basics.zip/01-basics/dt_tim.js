// Get the current date and time
const now = new Date()

// Get various components of the current date and time
const year = now.getFullYear()
const month = now.getMonth() + 1 // Months are zero-based, so we add 1
const day = now.getDate()
const hours = now.getHours()
const minutes = now.getMinutes()
const seconds = now.getSeconds()

// Format the date and time as a string
const formattedDateTime = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')} ${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

console.log("Current Date and Time:", formattedDateTime)

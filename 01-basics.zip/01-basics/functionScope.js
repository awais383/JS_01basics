// global scope
var c= 3000
let a=500
if (true){
    // local scope
    let a= 20
    const b= 30
    var c= 40
    console.log("inner", a)
    
}

// will display a is not defined
// will display b is not defined
// will display the value of c coz its type is var
// thats the reason var is not recommended in JS
console.log(c)
console.log(a)



function loginUserMessage(userName){
    return `${userName} user logged in`
}
console.log(loginUserMessage("awais"))
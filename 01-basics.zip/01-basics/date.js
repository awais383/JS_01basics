// dates

let myDate = new Date()
console.log(myDate.toString())
console.log(myDate.toLocaleString())
console.log(myDate.toLocaleDateString())



// my craeted date
let myTypedDate=new Date("2022,03,12")
console.log(myTypedDate.toDateString())

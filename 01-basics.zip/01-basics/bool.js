let isLoggedIn= "ali"

let booleanaIsLoggedIn= Boolean(isLoggedIn)

console.log(booleanaIsLoggedIn)
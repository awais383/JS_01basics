anyNumber= 55

let stringNumber= String(anyNumber)

console.log(stringNumber)

console.log(typeof(stringNumber))
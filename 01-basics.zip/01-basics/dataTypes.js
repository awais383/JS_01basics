"use strict" //treat all JS code as newer version

let age= 18
let isLoggedIn= false
let state= null
gpa= "3.1"

// DataTypes in JavaScript

/*
number =>2 to power 53
bigint
string =>""
boolean =>true/false
null
undefined
symbol =>unique
object
*/

console.log(typeof age);

console.log(typeof isLoggedIn)

console.log(typeof state)
 
console.log(typeof gpa)



// first method
// will also executed out of scope 
console.log(addOne(5))
function addOne(num){
    return num+ 1
}
// console.log(addOne(5))


// second method
// will not executed out of scope coz addTwo is stored in a variable
// console.log(addTwo(10))
const addTwo= function(num){
    return num+ 2
}
console.log(addTwo(10))


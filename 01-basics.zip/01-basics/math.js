console.log(Math)

// abs stands for absolute, always gives positive value
 console.log(Math.abs(-4))

// will round off
console.log(Math.round(5.6))

// will take upper value
console.log(Math.ceil(4.1))

// will take lower value
console.log(Math.floor(4.9))

// find the minimum value 
console.log(Math.min(3, 9, 14, 5, 11))

// find the maximum value 
console.log(Math.max(3, 9, 14, 5, 11))

// will give the output value between 0 and 1
// *10 for shift value to the right
// +1 to avoid floor
console.log(Math.random()*10 +1)


const max= 50
const min= 25
console.log(Math.random()*(max-min+10)+min)
console.log(Math.floor(Math.random()*(max-min+10)+min))

// console.log("ali")

const pi= 3.14
let age= "21"
var height= "12345"

console.log(age)

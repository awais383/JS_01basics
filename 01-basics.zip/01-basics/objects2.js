// singleton object
// const tinderUser= new Object


// non singleton object
 const tinderUser= {}
tinderUser.name= "awais"
tinderUser.id= "aw123"
tinderUser.email= "awais@gmail.com"
 console.log(tinderUser)

 // check whether this property includes or not
 console.log(tinderUser.hasOwnProperty("id"))
 console.log(tinderUser.hasOwnProperty("mail"))

const regularUser= {
    email: "ali@gmail.com",
    fullName: {
        userFullName: {
            firstName: "awais",
            lastName: "hanif",
        }
    }
}

console.log(regularUser.fullName.userFullName.lastName)


const obj1={1: "a", 2: "b", 3:"c"}
const obj2={4: "a", 5: "b", 6:"c"}
obj3= {obj1, obj2}

console.log(Object.keys(obj1))

console.log(Object.values(obj2))

// will print array into array
console.log(Object.entries(obj1))

// will print as it is
console.log(obj3)

// assign into one object
// '{}' is part of syntax
obj3= Object.assign({},obj1,obj2)
console.log(obj3)

// spread
obj3= {...obj1, ...obj2}
console.log(obj3)


// objects into array
const JSuser=[
    {
        name: "ali",
        id: "345",
    },

    {
        name: "umar",
        id: "985",
    },
    {
        name: "haris",
        id: "900"
    },
]

console.log(JSuser[0].name)
console.log(JSuser[2].id)
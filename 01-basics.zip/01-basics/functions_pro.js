function countCart(num1){
    return num1
}
console.log(countCart(3))

// will display only first number
console.log(countCart(200,300,400))

// rest operator is used to display multiple nmbers
function countCartPrice(...num1){
    return num1
}
// will display all the numbers
console.log(countCartPrice(200,300,400,500))

function countTotalCartPrice(val1,val2,...num1){
    return num1
}

// 200 in val1, 400 in val2 and others in rest operator
console.log(countTotalCartPrice(200,400,600,800,1000))

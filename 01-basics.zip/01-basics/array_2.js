arr1= ["awais", "ali", "haider"]
arr2= ["haris", "ahmad", "fahad"]

// will print array into array
arr1.push(arr2)
console.log(arr1)

const total= arr1.concat(arr2)
console.log(total)


// converting array into string by spread
const final_total= [...arr1, ...arr2]
console.log(final_total)
console.log(typeof final_total)


// will convert sub arrays into one array 
const anotherArray= [1,2,3,[4,[5,6]]]
const finalAnotherArray= anotherArray.flat(Infinity)
console.log(anotherArray)
console.log(finalAnotherArray)


// check the string whether it is an array
console.log(Array.isArray("awais"))

//converting string into array
console.log(Array.from("awais"))


//will return empty array in this case
console.log(Array.from({name: "awais"}))


score1= 100
score2= 200
score3= 300
console.log(Array.of(score1, score2, score3))
const age= 29

console.log(age)
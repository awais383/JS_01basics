const myArray= [2, 5, 9, 1, 7]

function returnSecondValue(getArray){
   return getArray[1]
}

console.log(returnSecondValue(myArray))

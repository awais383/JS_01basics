// const number= 400
// console.log(number)


const newNumber= new Number(400)
console.log(newNumber)
console.log(newNumber.toString())
console.log(newNumber.toString().length)


const anotherNumber= 723.98643
console.log(anotherNumber.toPrecision(4))


const hundreds= 1000000
console.log(hundreds.toLocaleString())

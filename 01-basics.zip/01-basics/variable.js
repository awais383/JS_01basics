const pi= 3.14
let age= "21"
var height= "12345"

// console.log(pi)
// console.log(age)
// console.log(height)

console.table(pi,age,height)


//declaring function in function
function one(){

    const username= "awais"
    const email= "awais@gmail.com"

    // child function can access parent function
    function two(){
       const address= "lahore"
       const age= 21

     console.log(age)
    }

    // will not executed coz of scope
    // console.log(age)

    // out of scope
    two()
  
}

// out of scope
one()


// by if statement
if(true){
    const username= "awais"
    if(username==="awais"){
        const website= " youTube"
        console.log(username+ website)
    }
    // will not executed out of scope
    // console.log(website)
    // but username is accesable in this scope
}
// this will also not executed out of scope
// console.log(username)


function addOne(num){
return num+ 1
}
console.log(addOne(5))


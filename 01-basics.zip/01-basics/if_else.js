if(5>10){

    console.log("five is greater than ten")
}

else if(5===10){

console.log("five is less than ten")
}
 
else{

console.log("five is less than ten")
}

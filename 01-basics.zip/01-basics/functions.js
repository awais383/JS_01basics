function sayMyName(){
console.log("A")
console.log("W")
console.log("A")
console.log("I")
console.log("S")
}

//sayMyName()


 function addTwoNumbers(number1, number2){
 console.log(number1 + number2)
 }
// addTwoNumbers(9,5)

// will give undefined output coz of console in function definition
 const result= addTwoNumbers(5,9)
console.log(result)


// function addTwoNumbers(number1, number2){
//     return (number1 + number2)
// }
// // addTwoNumbers(9,5)

// // will give correct output coz of return in function statement
// const result= addTwoNumbers(5,9)
// console.log(result)


// one more method 
function addTwoNumbers(number1, number2){
    console.log(number1+ number2)
}
let answer= addTwoNumbers(4,5)
return answer


function loginUserMessage(userName){
    return `${userName} user logged in`
}
console.log(loginUserMessage("awais"))








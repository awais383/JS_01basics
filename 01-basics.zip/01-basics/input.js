// let userInput= prompt("javaScript is my favouritr language")
// console.log(userInput)


// let userInput = prompt("Please enter your name:");
// console.log("Hello, " + userInput + "!");


let userInput = prompt("Please enter your name:");
if (userInput === null || userInput.trim() === "") {
    console.log("No name entered.");
} else {
    console.log("Hello, " + userInput + "!");
}


// singleton
// literals

//object.create


// declaring symbol
const mySym= Symbol("key1")
// declaring objects
const JSuser= {
    name: "Umar",
    "full Name": "Umar Farooq",
    age: 21,
    location: "islamabad",
    [mySym]: "mykey1",
    isLoggedIN: false,
    lastLoggedIn: ["monday", "sunday"]
}

console.log(JSuser.age)
//another method of caling
console.log(JSuser["age"])
// only this method is valid for accesing full name 
console.log(JSuser["full Name"])
// correct method of accessing symbol type
console.log(JSuser[mySym])
console.log(typeof mySym)


// overwriting the value
JSuser.location= "lahore"
console.log(JSuser.location)

// lock all the values
// Object.freeze(JSuser)

// no change after freezing
JSuser.location= "faisalabad"
console.log(JSuser.location)

// displaying all values
console.log(JSuser)


// function
JSuser.greeting= function(){
     console.log("hi, I am JS user")
}
JSuser.greetingTwo= function(){
  console.log(`hi, I am JS user, ${this.name}`)
 }
console.log(JSuser.greeting)
console.log(JSuser.greeting())
console.log(JSuser.greetingTwo())

